<div class="footer">
		<div class="footer-inner">
			2014 &copy; Maher Information.
		</div>
		<div class="footer-tools">
			<span class="go-top">
			<i class="icon-angle-up"></i>
			</span>
		</div>
	</div>