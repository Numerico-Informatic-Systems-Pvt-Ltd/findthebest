
<form action="" method="post" enctype="multipart/form-data">
    
    Email<input type="text" name="email"><br>
   Password <input type="password" name="password"><br>
    First Name<input type="text" name="f_name"><br>
    Last Name <input type="text" name="l_name"><br>
   Google ID <input type="text" name="google_id"><br>
    Facebook ID<input type="text" name="facebook_id"><br>
    Phone<input type="text" name="phone"><br>
    
    <input type="submit" name="submit" value="Register">
</form>