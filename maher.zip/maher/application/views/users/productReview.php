<form action="" method="post" enctype="multipart/form-data">
    Rate this Tablet <input type="text" name="rate"><br><br>
    Write your review<textarea name="review" rows="10" cols="50"></textarea><br>
    <input type="submit" value="submit" value="Submit">
</form>
